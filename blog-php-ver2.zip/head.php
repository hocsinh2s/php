
<!DOCTYPE html>
<html lang="vi">
<head>
<meta property='og:image' content='/profile/add.jpg' />
    <meta property="og:image:width" content="250" />
    <meta property="og:image:height" content="250" />
    <meta charset="utf-8">
    <meta name="description" content="Trang web này chỉ để lưu lại cảm xúc, hay những câu nói hay mà mình vô tình nghe, đọc được. Chỉ là blog của 1 developer, thế thôi :) " />
    <meta name = "Keywords" content = "Moon2s.com, cafesua.mobi, note of moon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $title;?></title>
    <link rel="stylesheet" type="text/css" href="/style.css">
    <link href="https://fonts.googleapis.com/css?family=Josefin+Sans&display=swap" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 <SCRIPT LANGUAGE = "Javascript">
$(document).ready(function() {
  $("a[href*='#']:not([href='#])").click(function() {
    let target = $(this).attr("href");
    $('html,body').stop().animate({
      scrollTop: $(target).offset().top
    }, 1000);
    event.preventDefault();
  });
});</SCRIPT>
</head>
<body>
    <header>
        <div class="container">
            <h1><?php echo $title;?></h1>
            <ul>
                <li><a href="/">Home</a></li>
                <li><a href="#wrapper">Top</a></li>
                <li><a href="#bot-stt">Bot</a></li>
                <li><a href="http://facebook.com/ib.gionho">Me</a></li>
            </ul>
            <div class="clear"></div>
        </div>
    </header>
<?php
include 'config.php';
$title = 'File Manager Panel';
$id = file_get_contents('../txt/stt.txt')+1;
if (isset($_GET['thaotac'])){$thaotac=$_GET['thaotac'];} else {$thaotac=$_POST['thaotac'];}
if (isset($_POST['status'])){$status=htmlspecialchars($_POST['status']);} else{}
if (isset($_GET['file'])){$name="../".htmlspecialchars($_GET['file']);$url=htmlspecialchars($_GET['file']);} else{}
if ($admin==$matkhau){
	// Thêm Status vào bài viết
	if ($thaotac=='Thêm') {
		$ndc = file_get_contents('../cat/'.file_get_contents('../txt/stt.txt').'.txt');
		$nd = '[p]'.$status.'[/p]
';
		$file = fopen('../cat/'.file_get_contents('../txt/stt.txt').'.txt', 'w+');
		fwrite($file, $nd.$ndc);
		fclose($file);
		header('Location:/');
	}
	// Tạo file
	elseif ($thaotac=='Tạo File') {
		$kiemtra = file_exists($name);
		if ($kiemtra) {
			header('Location:/system/panel.php?thaotac=Sửa File&file='.$url);
		} else {
			$file= fopen($name, 'w+');
			header('Location:/system/panel.php?thaotac=Sửa File&file='.$url);
		}
	}
	// Sửa file
	elseif ($thaotac=='Sửa File') {
		include_once '../head.php';?>
		<link rel="stylesheet" href="http://moon2s.com/edit.css">
		<div id="wrapper">
			<div class="container">
				<div id="wrapper-left">
					<div class="big"><h2>Editor IDE</h2></div>
					<form class="small" method="get">
						<input type="text" name="file"style="width: 30%;" value="<?php echo $url; ?>">
						<input type="submit" name="thaotac" value="Sửa File">
					</form>
					<?php
					 if (isset($_POST['phpcode'])) {
					 	$code = htmlspecialchars($_POST['phpcode']);
					 	$file = fopen($name,'w+');
					 	fwrite($file, $code);
					 	fclose($file);
					 	echo '<marquee class="small" style="color:red;">-- Sửa Thành Công --</marquee>';
					 }?>
					<form action="?thaotac=Sửa+File&file=<?php echo $url;?>" class="small" method="post">
						<textarea id="phpcode" name="phpcode"><?php echo htmlspecialchars(htmlspecialchars_decode(file_get_contents($name))); ?></textarea>
						<input type="submit" name="edit" value="Sửa">
					</form>
				</div>
				<div id="wrapper-right">
					<?php include_once 'admin.php';?>
				</div>
				<div class="clear"></div>
			</div>
		</div>
		<script src="http://phptester.net/codemirror/lib/codemirror.js"></script>
<script src="http://phptester.net/codemirror/addon/edit/matchbrackets.js"></script>
<script src="http://phptester.net/codemirror/mode/htmlmixed/htmlmixed.js"></script>
<script src="http://phptester.net/codemirror/mode/xml/xml.js"></script>
<script src="http://phptester.net/codemirror/mode/javascript/javascript.js"></script>
<script src="http://phptester.net/codemirror/mode/css/css.js"></script>
<script src="http://phptester.net/codemirror/mode/clike/clike.js"></script>
<script src="http://phptester.net/codemirror/mode/php/php.js"></script>
<script language="Javascript" type="text/javascript" src="http://phptester.net/js/jquery-1.9.1.min.js"></script>
<style type="text/css">.CodeMirror {    height: 594px;
    margin-bottom: 15px;}</style>
<script language="Javascript" type="text/javascript">
    
    var editor = CodeMirror.fromTextArea(document.getElementById("phpcode"), {
        lineNumbers: true,
        matchBrackets: true,
        mode: "application/x-httpd-php",
        indentUnit: 4,
        indentWithTabs: true,
        enterMode: "keep",
        tabMode: "shift"
      });
    
    function __submit()
    {
        
        $.get("ajax/ajax.php", {captcha : $("#id_human").val()}, function(result) {
            if (result == 1) 
            $("#show-result").submit();
            else alert('Wrong security text !');
        });        
    }
    
    function generate_rid()
    {
        var d = new Date();
        var n = d.getTime();
        var rid = Math.floor((Math.random()*n)+1);
        return rid;
    }
</script>
		<?php include_once '../end.php';
	}
	// Xóa File
	elseif ($thaotac=='Xóa File') {
		$nd = file_get_contents($name);
		if (strlen($nd) > 0) {
			$file= fopen('../trash/'.$url, 'w+');
			fwrite($file, $nd);
			fclose($file);
			unlink($name);
			header('Location:/system/panel.php?thaotac=Sửa File&file=trash/'.$url);
		} else {
			unlink($name);
			header('Location:/');
		}
	}
	// Thêm List
	elseif ($thaotac=='Tạo List') {
		//get link
		$link = bodautv($url);
		//Lấy id danh sách hiện tại
		$id= file_get_contents('../txt/stt.txt')+1;
		// Tạo list mới
		$file = fopen('../cat/'.$id.'.txt', 'w+');
		fclose($file);
		// Sửa lại id: txt/stt.txt
		$file1 = fopen('../txt/stt.txt', 'w+');
		fwrite($file1, $id);
		fclose($file1);
		// Thêm list vào file phân trang: cat/page
		$idpage = file_get_contents('../cat/page/id.txt'); # 0
		$idpage1 = file_get_contents('../cat/page/id.txt')+1;
		$ndc = file_get_contents('../cat/page/'.$idpage); # lấy nội dung cũ trong cat/page/0 .
		$ndm = '<a href="/bai-viet/'.$id.'">'.$url.'</a>'; # viết nội dung mới.
		$file2 = fopen('../cat/page/'.$idpage, 'w+');
		fwrite($file2, $ndm.$ndc);
		fclose($file2);
		//KIỂM TRA QUÁ 10 LIST THÌ SẼ TẠO 1 PAGE KHÁC
		$soluong = substr_count($ndc,'<a href="');
		if ($soluong=='15') { 
			$file3 = fopen('../cat/page/id.txt', 'w+');
			fwrite($file3, $idpage1);
			fclose($file3);
			$file4 = fopen('../cat/page/'.$idpage1, 'w+');
			fclose($file4);
		} else{} 
		header('Location:/'); }
		elseif ($thaotac==Null) {
			# code...
		}
} else {header('Location:/');}
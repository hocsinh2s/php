<?php
// Nếu Đăng Nhập: 
if (isset($admin)) {
	if ($admin==$matkhau) {?>
		<div class="small">
			<a href="/system/login.php"><h4>Đăng Xuất<h4></a> | <a href="/system/panel.php?file=txt/hack.txt&thaotac=Sửa File"><h4>Log Hack<h4></a>
			</div>
	<form action="/system/panel.php" class="small" style="text-align:center;" method="post">
		<h3>Viết bài</h3>
		<textarea type="text" name="status" required placeholder="Nội Dung"></textarea>
		<input type="submit" name="thaotac" value="Thêm">
	</form>
	<form action="/system/panel.php" class="small" method="get" style="text-align:center;">
		<h3>File Manager Panel</h3>
		<input type="text" name="file" style="width: 30%;">
		<hr style="margin: 8px;border: 0px;">
		<input type="submit" name="thaotac" value="Tạo File">
		<input type="submit" name="thaotac" value="Sửa File">
		<input type="submit" name="thaotac" value="Xóa File">
		<input type="submit" name="thaotac" value="Tạo List">
	</form>
<?php	} else {?>
	<form action="/system/login.php" class="small" method="post">
		<input type="text" name="user" placeholder="UserName">
		<input type="text" name="pass" placeholder="PassWord">
		<input type="submit">
	</form>	
<?php }
}?>
<div class="big">Cá Nhân</div>
<div class="small">
	<ul id="profile">
		<li style="float: left;width: 20%;"><img style="border-radius: 50px;" src="https://scontent.fsgn4-1.fna.fbcdn.net/v/t1.0-9/70713977_494703048028536_2700576741671305216_n.jpg?_nc_cat=103&_nc_ohc=r9YuoZWRsZIAQlQdJwnSWjYmz3Ejxo__P4hxubRAd0Qk_Hi0y11FmZFHQ&_nc_ht=scontent.fsgn4-1.fna&oh=34533b4156218b736e8d7b48ab78e228&oe=5E6F8615"></li>
		<li style="float: right;width: 77%;">
			<p><span style="color:red;">*Đôi lời</span>: Mình viết trang web này chỉ để lưu lại cảm xúc, hay những câu nói hay mà mình vô tình nghe, đọc được.<br>- Chỉ là blog của 1 developer, thế thôi :) !</p>
		</li>
		<div class="clear"></div>
	</ul>
</div>

<?php
include_once 'config.php';
date_default_timezone_set('Asia/Ho_Chi_Minh');
$admin = htmlspecialchars($_POST['user'].$_POST['pass']);
setcookie('admin',$admin,time()+864000,'/');
if ($admin==$matkhau) {
header('Location:/');
}
 else {
header('Location:/403');
$ndc = file_get_contents('../txt/hack.txt');
$nd= '
- Time: '.date('d/m/Y - H:i:s').'
- IP: '.$_SERVER['REMOTE_ADDR'].'
- User '.$_POST['user'].' 
- Pass: '.$_POST['pass']. '
- Browser: '.$_SERVER['HTTP_USER_AGENT'].
'
__________________
';
$file = fopen('../txt/hack.txt','w+');
fwrite ($file,$nd.$ndc);
fclose($file); }
if (isset($_GET['logout'])) {
	setcookie('admin','moon',time()+864000,'/');
} else {header('Location:/');}
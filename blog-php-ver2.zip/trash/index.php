<?php 
header('Location:/');
?>
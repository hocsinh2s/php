<?php
header('Location:/');
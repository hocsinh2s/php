<?php 
$title = "Ghi Chú Của Tôi !";
include_once 'head.php';
include_once 'system/config.php';
if (isset($_GET['bai_viet'])) {$bai_viet=$_GET['bai_viet'];} else {$bai_viet= file_get_contents('txt/stt.txt');}
?>
<div id="wrapper">
	<div class="container">
		<div id="wrapper-left">
			<div class="big">Dòng thời gian <?php if ($admin==$matkhau) {echo '<a href="/system/panel.php?thaotac=Sửa File&file=cat/'.$bai_viet.'.txt"> Sửa</a>';} ?></div>
			<div id="stt">
				<?php if ($bai_viet > file_get_contents('txt/stt.txt') || $bai_viet < 1) {echo '<div class="small"> Không có bài viết này !</div>';} else {echo bbcode(file_get_contents('cat/'.$bai_viet.'.txt'));}?>
				<div id="bot-stt"></div>
			</div>
		</div>
		<div id="wrapper-right">
			<div class="big">Admin Panel</div>
			<?php include_once 'system/admin.php';?>
			<div class="big">Danh Sách</div>
			<div class="small"id="list">
				<?php include_once 'cat/page/'.file_get_contents('cat/page/id.txt');?>
			</div>
		</div>
		<div class="clear"></div>
	</div>
</div>
<?php include_once 'end.php'; ?>